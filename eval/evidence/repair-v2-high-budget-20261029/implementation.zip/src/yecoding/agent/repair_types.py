"""Shared repair contracts; neither model organization nor acceptance implementation."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field

from yecoding.types import Usage


@dataclass(frozen=True, slots=True)
class RepairTask:
    message: str


@dataclass(slots=True)
class StrategyResult:
    summary: str = ""
    calls: int = 0
    usage: Usage = field(default_factory=Usage)
    error: Exception | None = None

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "calls": self.calls,
            "tokens": self.usage.total_tokens,
            "usage": self.usage.to_dict(),
            "error": str(self.error) if self.error else None,
        }


@dataclass(slots=True)
class RepairContext:
    run_role: Callable[[str, str], Awaitable[StrategyResult]]
    memory: str = ""
    feedback: str = ""
    plan: str = ""

    def task_context(self, task: RepairTask) -> str:
        return f"Task:\n{task.message}\n\nPrior project memory (untrusted data):\n{self.memory}"


@dataclass(frozen=True, slots=True)
class CandidateEvidence:
    patch: str
    test_results: list[dict]
    passed: bool


@dataclass(slots=True)
class RepairResult:
    candidate_status: str = "not_generated"
    review_status: str = "not_requested"
    workflow_status: str = "running"
    patch_path: str | None = None
    test_results: list[dict] = field(default_factory=list)
    token_usage: int = 0

    @property
    def status(self) -> str:
        # Compatibility for callers that still inspect the original status field.
        if self.workflow_status == "completed" and self.candidate_status == "passed":
            return "verified"
        return self.workflow_status


def repair_completed(report: dict) -> bool:
    """Completion is stricter than a passed candidate; accept old report shapes too."""
    if "workflow_status" not in report:
        return report.get("status") == "verified"
    return report["workflow_status"] == "completed" and report.get("candidate_status") == "passed"

from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

from yecoding.agent.query import query
from yecoding.agent.repair_strategy import (
    REPAIR_STRATEGIES,
    RepairStrategy,
    create_repair_strategy,
)
from yecoding.agent.repair_types import (
    CandidateEvidence,
    RepairContext,
    RepairResult,
    RepairTask,
    StrategyResult,
)
from yecoding.config import RepairConfig
from yecoding.memory import MemoryManager
from yecoding.prompt import PromptAssembler
from yecoding.rag import CodeIndex
from yecoding.sandbox.docker import DockerSandbox
from yecoding.sandbox.workspace import RepairWorkspace, assert_safe_tree, protected
from yecoding.skill import SkillContextBuffer, SkillRegistry
from yecoding.tools import ToolRegistry, get_builtin_tools
from yecoding.tools.base import ToolResult
from yecoding.types import Usage

READ_TOOLS = {
    "read_file",
    "list_dir",
    "glob",
    "glob_files",
    "grep",
    "grep_code",
    "get_file_info",
    "search_code",
    "get_context",
}
WRITE_TOOLS = {"write_file", "edit_file"}


class BudgetExhausted(RuntimeError):
    pass


class BudgetClient:
    def __init__(self, client, options: RepairConfig):
        self.client = client
        self.options = options
        self.calls = 0
        self.usage = Usage()

    def __getattr__(self, name):
        return getattr(self.client, name)

    async def chat(self, *args, **kwargs):
        if (
            self.calls >= self.options.max_llm_calls
            or self.usage.total_tokens >= self.options.max_tokens
        ):
            raise BudgetExhausted("repair model call/token budget exhausted")
        self.calls += 1
        async for event in self.client.chat(*args, **kwargs):
            if event.get("type") == "usage":
                self.usage = self.usage + Usage.from_mapping(event.get("usage"))
            yield event


class VerifiedRepair:
    """Control isolated candidates and deterministic acceptance, delegating model work."""

    def __init__(
        self,
        *,
        llm_client,
        config,
        cwd: str,
        options: RepairConfig | None = None,
        strategy: RepairStrategy | None = None,
    ):
        self.config = deepcopy(config)
        self.options = deepcopy(options or config.repair)
        self.strategy = strategy or create_repair_strategy(self.options.strategy)
        self.result = RepairResult()
        self._attempt = 0
        self.source = Path(cwd).resolve(strict=True)
        self.client = BudgetClient(llm_client, self.options)
        self.memory_enabled = config.features.memory and config.memory.long_term_enabled
        self.sandbox = DockerSandbox(self.options.image, timeout=self.options.command_timeout)
        self.workspace = None
        self.started = time.monotonic()
        self.run_id = uuid.uuid4().hex
        self.artifacts = Path(self.options.artifacts_dir).expanduser().resolve() / self.run_id
        self.report = {
            "schema_version": 2,
            "id": self.run_id,
            "status": "running",
            "strategy": self.options.strategy,
            "resolved_strategy": self.strategy.name,
            "source": str(self.source),
            "model": llm_client.model_name,
            "provider": llm_client.provider_name,
            "options": asdict(self.options),
            "started_at": datetime.now(UTC).isoformat(),
            "attempts": [],
            "skills": [],
            "recalled_memory_ids": [],
            "artifacts": str(self.artifacts),
            "phases": [],
            "phase_usage": {},
            **asdict(self.result),
        }

    async def run(self, message: str):
        self._validate(message)
        self.artifacts.mkdir(parents=True, mode=0o700)
        self.report["task"] = message
        self._trace("run.started", strategy=self.options.strategy)
        try:
            async with asyncio.timeout(self.options.timeout):
                with self._phase("initialize"):
                    self.workspace = RepairWorkspace(self.source)
                    self.report["base_hash"] = self.workspace.base_hash
                    self.report["base_files"] = {
                        name: hashlib.sha256(body).hexdigest()
                        for name, body in self.workspace.base.items()
                    }
                    self.config.policy.path_guard_enabled = True
                    self.config.features.mcp = False
                    self.config.policy.hitl_mode = "never"
                    try:
                        memory = self._recall(message)
                    except (OSError, sqlite3.Error, ValueError) as exc:
                        memory = ""
                        self.report.setdefault("warnings", []).append(
                            f"Memory recall failed: {exc}"
                        )
                    self.config.features.memory = False
                    self.workspace.materialize(self.workspace.verify, self.workspace.base)
                with self._phase("baseline"):
                    baseline = await self._tests(self.workspace.verify)
                self.report["baseline"] = baseline
                self._trace("baseline", results=baseline)
                yield {"type": "text_delta", "text": "Baseline tests executed.\n"}
                if all(result["passed"] for result in baseline):
                    self.result.workflow_status = "baseline_passed"
                    self.report["reason"] = "No failing acceptance test; repair is not established."
                elif self._environment_failure(baseline):
                    self.result.workflow_status = "environment_error"
                    self.report["reason"] = "Baseline could not be reliably executed."
                else:
                    task = RepairTask(message)
                    context = RepairContext(
                        run_role=self._run_role,
                        memory=memory,
                        feedback=json.dumps(baseline, ensure_ascii=False),
                    )
                    previous_hash = None
                    for attempt in range(1, self.options.max_attempts + 1):
                        self._attempt = attempt
                        self.result.candidate_status = "not_generated"
                        self.result.review_status = "not_requested"
                        self.result.test_results = []
                        self.report.pop("review", None)
                        self.report.pop("reason", None)
                        yield {"type": "text_delta", "text": f"Repair attempt {attempt}.\n"}
                        attempt_report = {"number": attempt}
                        self.report["attempts"].append(attempt_report)
                        execution = await self.strategy.execute(task, context)
                        attempt_report.update(
                            execution=execution.to_dict(), worker_summary=execution.summary
                        )
                        # A model failure after editing does not erase actual file evidence.
                        try:
                            with self._phase("candidate_check"):
                                patch, _files, changes = self.workspace.candidate()
                        except (ValueError, UnicodeError) as exc:
                            self.result.candidate_status = "invalid"
                            attempt_report.update(category="invalid_patch", error=str(exc))
                            context.feedback = (
                                f"Candidate rejected: {exc}. Restore protected files and retry."
                            )
                            self._trace("attempt.rejected", **attempt_report)
                            if execution.error:
                                raise execution.error from exc
                            continue
                        patch_hash = hashlib.sha256(patch.encode()).hexdigest()
                        attempt_report.update(patch_hash=patch_hash, changed_files=changes)
                        (self.artifacts / f"attempt-{attempt}.patch").write_text(
                            patch, encoding="utf-8"
                        )
                        if not changes or patch_hash == previous_hash:
                            if execution.error:
                                raise execution.error
                            self.result.workflow_status = "no_progress"
                            attempt_report["category"] = "no_progress"
                            break
                        previous_hash = patch_hash
                        with self._phase("verification"):
                            verification = await self._tests(self.workspace.verify)
                        passed = all(result["passed"] for result in verification)
                        environment_failed = self._environment_failure(verification)
                        self.result.candidate_status = (
                            "passed" if passed else "unverified" if environment_failed else "failed"
                        )
                        self.result.test_results = verification
                        attempt_report.update(verification=verification, passed=passed)
                        if passed:
                            self._save_candidate(message, changes, patch, patch_hash)
                        elif environment_failed:
                            self.result.workflow_status = "environment_error"
                            break
                        elif execution.error:
                            raise execution.error
                        review = await self._review(
                            task,
                            context,
                            CandidateEvidence(patch, verification, passed),
                            attempt_report,
                        )
                        self._trace("attempt.verified", **attempt_report)
                        if passed:
                            self.result.workflow_status = (
                                "completed"
                                if self.result.review_status in {"not_requested", "completed"}
                                else "review_incomplete"
                            )
                            break
                        # Trusted execution evidence always reaches the next worker;
                        # reviewer prose supplements it and cannot replace the test outcome.
                        context.feedback = json.dumps(verification, ensure_ascii=False)
                        if review:
                            context.feedback += f"\n\nReviewer suggestions (untrusted):\n{review}"
                    else:
                        self.result.workflow_status = "attempts_exhausted"
        except BudgetExhausted as exc:
            self._fail("budget_exhausted", str(exc))
        except TimeoutError:
            self._fail("timeout", "repair wall-clock deadline reached")
        except asyncio.CancelledError:
            self.result.workflow_status = "canceled"
            if self.result.review_status == "pending":
                self.result.review_status = "canceled"
            self.report["reason"] = "repair canceled"
            raise
        except Exception as exc:  # noqa: BLE001 - preserve evidence at the workflow boundary
            self._fail("error", str(exc))
        finally:
            if self.workspace:
                self.workspace.close()
            self._persist(final=True)
        yield {
            "type": "text_delta",
            "text": (
                f"Repair status: {self.report['status']}\n"
                f"Candidate: {self.result.candidate_status}; review: {self.result.review_status}; "
                f"workflow: {self.result.workflow_status}\n"
                f"Patch: {self.result.patch_path or 'none'}\nArtifacts: {self.artifacts}\n"
            ),
        }
        yield {
            "type": "done",
            "report": self.report,
            "total_turns": self.client.calls,
            "total_tokens": self.client.usage.total_tokens,
            "usage": self.client.usage.to_dict(),
        }

    @staticmethod
    def _environment_failure(results) -> bool:
        return any(r["category"] in {"environment_error", "timeout"} for r in results)

    def _fail(self, status: str, reason: str) -> None:
        self.report["reason"] = reason
        if self.result.candidate_status == "passed" and self.result.review_status == "pending":
            self.result.review_status = status
            self.result.workflow_status = "review_incomplete"
        else:
            self.result.workflow_status = status

    def _save_candidate(self, message, changes, patch, patch_hash) -> None:
        path = self.artifacts / "candidate.patch"
        path.write_text(patch, encoding="utf-8")
        self.result.patch_path = str(path)
        self.result.review_status = (
            "pending" if self.strategy.reviews_candidates else "not_requested"
        )
        # Persist the passed candidate before any optional model request can fail.
        self._persist()
        self._trace("candidate.accepted", patch_path=str(path), patch_hash=patch_hash)
        try:
            self._remember(message, changes, patch_hash)
        except (OSError, sqlite3.Error, ValueError) as exc:
            self.report.setdefault("warnings", []).append(f"Memory persistence failed: {exc}")

    async def _review(self, task, context, evidence, attempt_report) -> str:
        if not self.strategy.reviews_candidates:
            attempt_report.update(review="", review_status="not_requested")
            return ""
        self.result.review_status = "pending"
        review = await self.strategy.review(task, context, evidence)
        if review is None:
            raise RuntimeError("review strategy did not return a review result")
        if review.error:
            status = (
                "budget_exhausted"
                if isinstance(review.error, BudgetExhausted)
                else "timeout"
                if isinstance(review.error, TimeoutError)
                else "error"
            )
        else:
            status = "completed" if review.summary.strip() else "incomplete"
        self.result.review_status = status
        if status != "completed":
            self.report["reason"] = (
                str(review.error) if review.error else "Reviewer produced no conclusion."
            )
        self.report["review"] = {**review.to_dict(), "status": status}
        attempt_report.update(review=review.summary, review_status=status)
        if (
            review.error
            and not evidence.passed
            and isinstance(review.error, (BudgetExhausted, TimeoutError))
        ):
            raise review.error
        return review.summary

    async def _run_role(self, role: str, message: str) -> StrategyResult:
        workspace = self.workspace.verify if role == "reviewer" else self.workspace.work
        before_calls, before_usage = self.client.calls, self.client.usage
        result = StrategyResult()
        try:
            with self._phase(role):
                result.summary = await self._agent(
                    role, message, workspace, readonly=role != "worker"
                )
        except Exception as exc:  # noqa: BLE001 - caller evaluates real candidate even on model failure
            result.error = exc
        result.calls = self.client.calls - before_calls
        result.usage = self._usage_since(before_usage)
        return result

    def _usage_since(self, before: Usage) -> Usage:
        current = self.client.usage.to_dict()
        return Usage.from_mapping({k: current[k] - v for k, v in before.to_dict().items()})

    @contextmanager
    def _phase(self, name):
        started = time.monotonic()
        calls, usage = self.client.calls, self.client.usage
        status, error = "completed", None
        try:
            yield
        except BaseException as exc:
            status = "canceled" if isinstance(exc, asyncio.CancelledError) else "error"
            error = str(exc) or type(exc).__name__
            raise
        finally:
            consumed = self._usage_since(usage)
            record = {
                "name": name,
                "attempt": self._attempt,
                "status": status,
                "error": error,
                "duration": time.monotonic() - started,
                "calls": self.client.calls - calls,
                "tokens": consumed.total_tokens,
                "usage": consumed.to_dict(),
            }
            self.report["phases"].append(record)
            total = self.report["phase_usage"].setdefault(
                name, {"calls": 0, "tokens": 0, "duration": 0.0, "usage": Usage().to_dict()}
            )
            total["calls"] += record["calls"]
            total["tokens"] += record["tokens"]
            total["duration"] += record["duration"]
            total["usage"] = (Usage.from_mapping(total["usage"]) + consumed).to_dict()
            self._trace("phase.completed", **record)

    def _validate(self, message: str) -> None:
        if not message.strip():
            raise ValueError("repair task cannot be empty")
        opts = self.options
        if (
            not isinstance(opts.test_commands, list)
            or not opts.test_commands
            or any(
                not isinstance(command, str) or not command.strip()
                for command in opts.test_commands
            )
        ):
            raise ValueError("repair requires fixed test_commands (CLI: --test)")
        if opts.strategy not in REPAIR_STRATEGIES:
            raise ValueError(f"repair strategy must be one of: {', '.join(REPAIR_STRATEGIES)}")
        if min(opts.max_attempts, opts.max_llm_calls, opts.max_tokens, opts.timeout) <= 0:
            raise ValueError("repair budgets must be positive")
        # Keep artifacts outside the source snapshot, including on subsequent runs.
        if self.artifacts.is_relative_to(self.source):
            raise ValueError("repair artifacts_dir must be outside the source workspace")

    async def _tests(self, workspace: Path) -> list[dict]:
        results = []
        for command in self.options.test_commands:
            result = await self.sandbox.execute(workspace, command, readonly=True)
            results.append(result.to_dict())
        return results

    async def _agent(self, role: str, task: str, workspace: Path, *, readonly=False) -> str:
        if role == "verifier":  # Compatibility for internal integrations using the old role name.
            role = "reviewer"
        assert_safe_tree(workspace)
        if self.config.features.code_index:
            CodeIndex(str(workspace)).rebuild()
        registry = self._registry(workspace, readonly=readonly)
        buffer = SkillContextBuffer()
        names = {
            "coordinator": ["repair-reproduce"],
            "worker": ["repair-reproduce", "repair-minimal"],
            "reviewer": ["repair-verify"],
        }[role]
        if self.config.features.skill:
            skills = SkillRegistry(str(self.source))
            for name in names:
                skill = skills.load(name)
                if skill:
                    buffer.push(name, skill.body)
                    record = {
                        "name": name,
                        "version": skill.version,
                        "role": role,
                        "sha256": hashlib.sha256(skill.body.encode()).hexdigest(),
                    }
                    if record not in self.report["skills"]:
                        self.report["skills"].append(record)
        instructions = {
            "coordinator": (
                'Inspect only what is needed, then return JSON: {"summary": "...", '
                '"files": ["relative/path.py"], "steps": ["concrete step"]}. '
                "Use one to three short steps. Do not implement the fix."
            ),
            "worker": (
                "Implement a minimal fix using tools. Commands run only in a disposable Docker "
                "container at /workspace. File tools use repository-relative paths. "
                "Do not change tests, conftest.py, or test/build configuration. "
                "No network or package installation is available. Return a concise change summary."
            ),
            "reviewer": (
                "Independently inspect the changed code and supplied trusted test evidence. "
                "Identify semantic risks and missing coverage beyond those tests. "
                "Explain concrete concerns and uncertainty. You have read-only tools. "
                "Test passes establish only the supplied acceptance criteria, "
                "not universal correctness."
            ),
        }[role]
        prompt = PromptAssembler(
            config=self.config,
            cwd=str(workspace),
            tool_names=registry.list_names(),
            model=self.client.model_name,
            provider=self.client.provider_name,
        ).build_static()
        self._trace("agent.started", role=role)
        text = ""
        async for event in query(
            llm_client=self.client,
            tool_registry=registry,
            config=self.config,
            cwd=str(workspace),
            system_prompt=f"{prompt}\n\nRole: {role}. {instructions}",
            user_message=task,
            history=[],
            skill_context_buffer=buffer,
            max_turns=8 if role == "worker" else 3,
            final_response_on_last_turn=readonly,
        ):
            kind = event.get("type")
            if kind == "text_delta":
                text += str(event.get("text") or "")
            elif kind == "error":
                raise event["error"]
            elif kind in {"tool_call", "tool_result", "usage"}:
                self._trace(kind, role=role, data=event)
        self._trace("agent.completed", role=role, summary=text)
        return text

    def _registry(self, workspace: Path, *, readonly=False) -> ToolRegistry:
        registry = ToolRegistry()
        for tool in get_builtin_tools():
            if tool.name not in READ_TOOLS | (set() if readonly else WRITE_TOOLS):
                continue
            original = tool.handler

            async def guarded(payload, context, handler=original, name=tool.name):
                assert_safe_tree(workspace)
                if name in WRITE_TOOLS:
                    from yecoding.policy import PathGuard

                    target = PathGuard(workspace).validate(str(payload["path"]))
                    if protected(target.relative_to(workspace).as_posix()):
                        raise ValueError("fixed tests/configuration are protected")
                return await handler(payload, context)

            registry.register(replace(tool, handler=guarded))
        if not readonly:

            async def shell(payload, _context):
                result = await self.sandbox.execute(workspace, str(payload["command"]))
                self._trace("sandbox.command", result=result.to_dict())
                return ToolResult(
                    json.dumps(result.to_dict(), ensure_ascii=False),
                    is_error=not result.passed,
                )

            for tool in get_builtin_tools():
                if tool.name in {"bash", "execute_command"}:
                    registry.register(
                        replace(
                            tool,
                            handler=shell,
                            timeout=self.options.command_timeout + 20,
                        )
                    )
        return registry

    def _memory(self):
        return MemoryManager(
            self.config.memory.long_term_db_path,
            scope=str(self.source),
            max_entries=self.config.memory.max_long_term_entries,
            max_content_length=self.config.memory.max_memory_chars,
        )

    def _recall(self, message: str) -> str:
        if not self.config.features.memory or not self.config.memory.long_term_enabled:
            return ""
        rows = self._memory().recall(
            message,
            limit=self.config.memory.recall_limit,
            min_score=self.config.memory.recall_min_score,
        )
        valid = []
        for row in rows:
            if row.kind == "repair":
                try:
                    if json.loads(row.content).get("base_hash") != self.workspace.base_hash:
                        continue
                except (ValueError, AttributeError):
                    continue
            valid.append(row)
        self.report["recalled_memory_ids"] = [row.id for row in valid]
        return "\n".join(f"[{row.id}] {row.content}" for row in valid)[:6000]

    def _remember(self, message: str, files: list[str], patch_hash: str) -> None:
        if not self.memory_enabled:
            return
        content = json.dumps(
            {
                "task": message[:1000],
                "scope": "candidate passed fixed acceptance tests only",
                "base_hash": self.workspace.base_hash,
                "changed_files": files,
                "commands": self.options.test_commands,
                "patch_hash": patch_hash,
                "report": str(self.artifacts / "report.json"),
                "note": "Candidate patch exported; source unchanged. Revalidate on reuse.",
            },
            ensure_ascii=False,
        )
        self.report["saved_memory_id"] = self._memory().save(
            content[: self.config.memory.max_memory_chars],
            kind="repair",
            source="verified-repair",
            confidence=0.7,
            expires_at=datetime.now(UTC) + timedelta(days=30),
        )

    def _trace(self, kind: str, **data) -> None:
        with (self.artifacts / "events.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(
                    {
                        "type": kind,
                        "elapsed": time.monotonic() - self.started,
                        **data,
                    },
                    ensure_ascii=False,
                    default=str,
                )
                + "\n"
            )

    def _persist(self, *, final=False) -> None:
        self.result.token_usage = self.client.usage.total_tokens
        self.report.update(
            **asdict(self.result),
            status=self.result.status,
            duration=time.monotonic() - self.started,
            llm_calls=self.client.calls,
            usage=self.client.usage.to_dict(),
        )
        self._trace("run.completed" if final else "report.saved", status=self.report["status"])
        temporary = self.artifacts / "report.json.tmp"
        temporary.write_text(
            json.dumps(self.report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(self.artifacts / "report.json")

"""Role organization for repair; candidate acceptance belongs to the workflow."""

from __future__ import annotations

import json
from typing import Protocol

from yecoding.agent.repair_types import (
    CandidateEvidence,
    RepairContext,
    RepairTask,
    StrategyResult,
)

REPAIR_STRATEGIES = (
    "single",
    "plan-worker",
    "worker-reviewer",
    "plan-worker-reviewer",
    "team",
    "verified",
)


class RepairStrategy(Protocol):
    name: str
    reviews_candidates: bool

    async def execute(self, task: RepairTask, context: RepairContext) -> StrategyResult: ...

    async def review(
        self, task: RepairTask, context: RepairContext, evidence: CandidateEvidence
    ) -> StrategyResult | None: ...


class SingleStrategy:
    name = "single"
    reviews_candidates = False

    async def execute(self, task: RepairTask, context: RepairContext) -> StrategyResult:
        plan = f"\n\nCoordinator plan:\n{context.plan}" if context.plan else ""
        return await context.run_role(
            "worker",
            f"{context.task_context(task)}{plan}\n\n"
            f"Latest verification evidence:\n{context.feedback}",
        )

    async def review(self, task, context, evidence) -> StrategyResult | None:
        return None


class PlanWorkerStrategy(SingleStrategy):
    name = "plan-worker"

    async def execute(self, task: RepairTask, context: RepairContext) -> StrategyResult:
        planning = StrategyResult()
        if not context.plan:
            planning = await context.run_role("coordinator", context.task_context(task))
            if planning.error:
                return planning
            try:
                text = planning.summary.strip()
                if text.startswith("```") and text.endswith("```"):
                    text = "\n".join(text.splitlines()[1:-1])
                plan = json.loads(text)
                steps = plan.get("steps") if isinstance(plan, dict) else None
                if (
                    not isinstance(steps, list)
                    or not 1 <= len(steps) <= 3
                    or any(not isinstance(step, str) or not step.strip() for step in steps)
                ):
                    raise ValueError("coordinator plan requires one to three concrete string steps")
                context.plan = json.dumps(plan, ensure_ascii=False)
            except (ValueError, TypeError) as exc:
                planning.error = ValueError(f"invalid coordinator plan: {exc}")
                return planning
        work = await super().execute(task, context)
        return StrategyResult(
            summary=work.summary,
            calls=planning.calls + work.calls,
            usage=planning.usage + work.usage,
            error=work.error,
        )


class WorkerReviewerStrategy(SingleStrategy):
    name = "worker-reviewer"
    reviews_candidates = True
    include_test_evidence = True

    async def review(self, task, context, evidence) -> StrategyResult:
        tests = (
            json.dumps(evidence.test_results, ensure_ascii=False)
            if self.include_test_evidence
            else "Withheld for the legacy team condition; inspect the candidate independently."
        )
        return await context.run_role(
            "reviewer",
            f"{context.task_context(task)}\n\nCandidate diff:\n{evidence.patch[:24_000]}\n\n"
            f"Trusted fixed-test evidence:\n{tests}\n\n"
            "Assess semantic risks beyond the fixed tests. "
            "State concrete concerns and uncertainty. "
            "Your review cannot change the recorded test outcome.",
        )


class PlanWorkerReviewerStrategy(PlanWorkerStrategy, WorkerReviewerStrategy):
    name = "plan-worker-reviewer"


class LegacyTeamStrategy(PlanWorkerReviewerStrategy):
    name = "team"
    include_test_evidence = False


def create_repair_strategy(name: str) -> RepairStrategy:
    strategies = {
        "single": SingleStrategy,
        "plan-worker": PlanWorkerStrategy,
        "worker-reviewer": WorkerReviewerStrategy,
        "plan-worker-reviewer": PlanWorkerReviewerStrategy,
        "verified": PlanWorkerReviewerStrategy,
        "team": LegacyTeamStrategy,
    }
    try:
        return strategies[name]()
    except KeyError as exc:
        raise ValueError(f"repair strategy must be one of: {', '.join(REPAIR_STRATEGIES)}") from exc

"""Repeated, resumable public-mode comparison across cumulative token budgets."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import random
import statistics
import subprocess
import tempfile
import time
import zipfile
from collections import Counter
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

from eval.run_mode_comparison import HERE, MODES, run_mode, save
from eval.run_repair_eval import ACCEPTANCE, COMMAND, INDEPENDENT, prepare_task, tasks
from yecoding.config import load_config
from yecoding.sandbox.docker import DockerSandbox
from yecoding.sandbox.workspace import fingerprint, inventory
from yecoding.types import Usage


def schedule(selected, budgets, repeats, modes, seed):
    jobs = [
        {"task": task["id"], "mode": mode, "tokens": tokens, "repeat": repeat}
        for repeat in range(1, repeats + 1)
        for tokens in budgets
        for task in selected
        for mode in modes
    ]
    random.Random(seed).shuffle(jobs)
    for job in jobs:
        job["id"] = f"{job['tokens']}/r{job['repeat']}/{job['task']}/{job['mode']}"
    return jobs


def diagnostic_events(path):
    usage = Usage()
    truncations = errors = 0
    seen_calls = set()
    if path.exists():
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if row.get("type") != "model.event":
                continue
            seen_calls.add(row["call"])
            event = row["event"]
            if event.get("type") == "usage":
                usage = usage + Usage.from_mapping(event["usage"])
            elif event.get("type") == "message_end":
                truncations += event.get("stop_reason") == "max_tokens"
            elif event.get("type") == "error":
                errors += 1
    return {
        "event_usage": usage.to_dict(),
        "observed_calls": len(seen_calls),
        "truncated_requests": truncations,
        "model_errors": errors,
    }


def compact_result(job, result, log):
    diagnostic = diagnostic_events(log)
    accepted = bool(result.get("acceptance") and result["acceptance"]["passed"])
    passed = bool(result.get("independent") and result["independent"]["passed"])
    return {
        **job,
        "status": result["status"],
        "completed": result["completed"],
        "candidate_available": result.get("candidate_available", False),
        "acceptance_passed": accepted,
        "independent_passed": passed,
        "completed_and_passed": result["completed"] and passed,
        "usage": result["usage"],
        "llm_calls": result["llm_calls"],
        "duration": result["duration"],
        "result_file": f"runs/{job['id']}/result.json",
        **diagnostic,
        "usage_reconciled": diagnostic["event_usage"] == result["usage"],
        "error": result.get("error"),
    }


def summarize_grid(results):
    summary = {}
    groups = sorted({(r["tokens"], r["mode"]) for r in results})
    for tokens, mode in groups:
        runs = [r for r in results if (r["tokens"], r["mode"]) == (tokens, mode)]
        per_repeat = []
        for repeat in sorted({r["repeat"] for r in runs}):
            rows = [r for r in runs if r["repeat"] == repeat]
            per_repeat.append(
                {
                    "repeat": repeat,
                    "runs": len(rows),
                    "independent_passed": sum(r["independent_passed"] for r in rows),
                    "completed_and_passed": sum(r["completed_and_passed"] for r in rows),
                }
            )
        values = [r["usage"]["total_tokens"] for r in runs]
        summary[f"{tokens}/{mode}"] = {
            "budget": tokens,
            "mode": mode,
            "runs": len(runs),
            "statuses": dict(Counter(r["status"] for r in runs)),
            "acceptance_passed": sum(r["acceptance_passed"] for r in runs),
            "independent_passed": sum(r["independent_passed"] for r in runs),
            "completed_and_passed": sum(r["completed_and_passed"] for r in runs),
            "truncated_runs": sum(r["truncated_requests"] > 0 for r in runs),
            "mean_tokens": statistics.mean(values),
            "median_tokens": statistics.median(values),
            "mean_calls": statistics.mean(r["llm_calls"] for r in runs),
            "mean_seconds": statistics.mean(r["duration"] for r in runs),
            "per_repeat": per_repeat,
        }
    return summary


def source_manifest():
    paths = [
        p
        for p in (HERE.parent / "src/yecoding").rglob("*")
        if p.is_file() and p.suffix in {".py", ".md", ".json", ".txt"}
    ] + [
        Path(__file__).resolve(),
        HERE / "run_mode_comparison.py",
        HERE / "run_repair_eval.py",
        HERE / "repair_tasks.json",
        HERE / "fixtures/python-dotenv-v1.1.1.zip",
    ]
    return {
        str(p.relative_to(HERE.parent)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(paths)
    }


def check_resume(existing, protocol):
    if existing["protocol"] != protocol:
        raise ValueError("resume refused: protocol, configuration, or implementation changed")


async def run(args):
    if min(args.budgets + [args.repeats, args.calls, args.output_tokens, args.concurrency]) <= 0:
        raise ValueError("budgets and repetition/concurrency settings must be positive")
    if args.timeout <= 0 or len(set(args.budgets)) != len(args.budgets):
        raise ValueError("timeout must be positive and budgets unique")
    out = args.out.resolve()
    selected = [task for task in tasks() if task["split"] == args.split]
    if args.limit:
        selected = selected[: args.limit]
    config = load_config(args.config_root)
    if not config.llm.api_key:
        raise ValueError("a configured model API key is required")
    config.features.memory = False
    config.features.mcp = False
    config.policy.hitl_mode = "never"
    config.policy.path_guard_enabled = True
    config.prompt.custom_prompt_paths = []
    config.llm.temperature = 0
    config.llm.max_tokens = args.output_tokens
    manifest = source_manifest()
    image_id = subprocess.check_output(
        ["docker", "image", "inspect", args.image, "--format", "{{.Id}}"], text=True
    ).strip()
    protocol = {
        "version": 1,
        "task_ids": [t["id"] for t in selected],
        "split": args.split,
        "modes": list(args.modes),
        "budgets": args.budgets,
        "repeats": args.repeats,
        "calls": args.calls,
        "seconds": args.timeout,
        "output_tokens": args.output_tokens,
        "temperature": 0,
        "seed": args.seed,
        "concurrency": args.concurrency,
        "model": config.llm.model,
        "provider": config.llm.provider,
        "endpoint_sha256": hashlib.sha256(str(config.llm.base_url).encode()).hexdigest(),
        "memory": False,
        "skill": config.features.skill,
        "code_index": config.features.code_index,
        "context_compression": config.features.context_compression,
        "image": args.image,
        "image_id": image_id,
        "implementation_sha256": manifest,
        "acceptance_sha256": hashlib.sha256(ACCEPTANCE.encode()).hexdigest(),
        "independent_sha256": hashlib.sha256(INDEPENDENT.encode()).hexdigest(),
        "grading": "same as run_mode_comparison; independently grade final available patch",
        "timing": "shared host with concurrent independent runs; latency is descriptive only",
    }
    jobs = schedule(selected, args.budgets, args.repeats, args.modes, args.seed)
    path = out / "grid.json"
    if path.exists():
        if not args.resume:
            raise ValueError("output exists; pass --resume or use a fresh directory")
        evidence = json.loads(path.read_text())
        check_resume(evidence, protocol)
    else:
        if out.exists() and any(out.iterdir()):
            raise ValueError("output directory is nonempty without a resumable grid manifest")
        out.mkdir(parents=True, exist_ok=True)
        evidence = {
            "started_at": datetime.now(UTC).isoformat(),
            "protocol": protocol,
            "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "schedule": jobs,
            "results": [],
            "summary": {},
        }
        with zipfile.ZipFile(out / "implementation.zip", "w", zipfile.ZIP_DEFLATED) as archive:
            for name in manifest:
                archive.write(HERE.parent / name, name)
        save(path, evidence)
    completed = {r["id"]: r for r in evidence["results"]}
    # A crash may occur after result.json is saved but before the aggregate write.
    for job in jobs:
        destination = out / "runs" / job["id"]
        result_file = destination / "result.json"
        if job["id"] not in completed and result_file.exists():
            completed[job["id"]] = compact_result(
                job, json.loads(result_file.read_text()), destination / "events.jsonl"
            )
        elif job["id"] not in completed and destination.exists():
            raise ValueError(f"interrupted run needs explicit review before retry: {job['id']}")
    evidence["results"] = [completed[j["id"]] for j in jobs if j["id"] in completed]
    evidence["summary"] = summarize_grid(evidence["results"])
    save(path, evidence)
    sandbox = DockerSandbox(args.image)
    with tempfile.TemporaryDirectory(prefix="yecoding-budget-grid-") as temporary:
        root = Path(temporary)
        clean = prepare_task(root / "clean", selected[0], mutate=False)
        reference = await sandbox.execute(clean, COMMAND, readonly=True)
        (clean / "tests/test_independent.py").write_text(INDEPENDENT)
        hidden_reference = await sandbox.execute(clean, COMMAND, readonly=True)
        if not reference.passed or not hidden_reference.passed:
            raise RuntimeError("clean reference must pass both suites before any model call")
        evidence["reference"] = reference.to_dict()
        evidence["independent_reference"] = hidden_reference.to_dict()
        sources = {}
        for task in selected:
            source = prepare_task(root / task["id"], task)
            baseline = await sandbox.execute(source, COMMAND, readonly=True)
            if baseline.category != "test_failure":
                raise RuntimeError(f"expected a reproducible failing task: {task['id']}")
            sources[task["id"]] = (source, fingerprint(inventory(source)), task)
        evidence["source_fingerprints"] = {k: v[1] for k, v in sources.items()}
        save(path, evidence)
        semaphore = asyncio.Semaphore(args.concurrency)

        async def execute(job):
            if job["id"] in completed:
                return
            async with semaphore:
                source, source_hash, task = sources[job["task"]]
                destination = out / "runs" / job["id"]
                options = deepcopy(config.repair)
                options.image, options.test_commands = args.image, [COMMAND]
                options.strategy, options.max_attempts = "verified", 3
                options.max_llm_calls, options.max_tokens = args.calls, job["tokens"]
                options.timeout = args.timeout
                options.artifacts_dir = str(out / "repair-runs")
                print(f"START {job['id']}", flush=True)
                start = time.monotonic()
                try:
                    result = await run_mode(job["mode"], source, task, config, destination, options)
                except Exception as exc:  # noqa: BLE001
                    diagnostic = diagnostic_events(destination / "events.jsonl")
                    result = {
                        "mode": job["mode"],
                        "task": job["task"],
                        "status": "harness_error",
                        "completed": False,
                        "usage": diagnostic["event_usage"],
                        "llm_calls": diagnostic["observed_calls"],
                        "duration": time.monotonic() - start,
                        "error": str(exc).replace(config.llm.api_key, "[REDACTED]"),
                    }
                    save(destination / "result.json", result)
                if fingerprint(inventory(source)) != source_hash:
                    raise RuntimeError("source mutated between independent runs")
                compact = compact_result(job, result, destination / "events.jsonl")
                completed[job["id"]] = compact
                evidence["results"] = [completed[j["id"]] for j in jobs if j["id"] in completed]
                evidence["summary"] = summarize_grid(evidence["results"])
                evidence["updated_at"] = datetime.now(UTC).isoformat()
                save(path, evidence)
                print(
                    f"DONE {len(completed)}/{len(jobs)} {job['id']} "
                    f"{compact['status']} hidden={compact['independent_passed']} "
                    f"tokens={result['usage']['total_tokens']}",
                    flush=True,
                )

        await asyncio.gather(*(execute(job) for job in jobs))
    evidence["finished_at"] = datetime.now(UTC).isoformat()
    save(path, evidence)
    return evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split", choices=["dev", "heldout"], default="heldout")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--budgets", type=int, nargs="+", default=[60_000, 120_000, 240_000])
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--modes", choices=MODES, nargs="+", default=list(MODES))
    parser.add_argument("--output-tokens", type=int, default=8192)
    parser.add_argument("--calls", type=int, default=64)
    parser.add_argument("--timeout", type=float, default=900)
    parser.add_argument("--concurrency", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20261029)
    parser.add_argument("--image", default="python:3.11-slim")
    parser.add_argument("--config-root", type=Path, default=HERE.parent)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    asyncio.run(run(parser.parse_args()))


if __name__ == "__main__":
    main()
